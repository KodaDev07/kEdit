import os

main_path = os.path.dirname(os.path.realpath(__file__))

def conf(data: str = '') -> bool | int:
    conftbl = {
        'sure': 'Are you sure?\n{y/n}:'
    }
    if data in conftbl:
        prompt = conftbl[data]
        c = input(f'{prompt}')
        if c.lower() in ('y', 'yes'):
            return True
        elif c.lower() in ('n', 'no'):
            return False
        else:
            return 1
    return True

class ini:
    def __init__(self):
        # Hardcoded values instead of reading config.ini
        self.data = {
            'editor': {
                '!save_dir': None,  # Will prompt the user to input path
                '!input_csr': ':>'  # Hardcoded input cursor value
            },
            'display': {
                'border_char': '#'
            }
        }

    def set(self, group: str, var: str, value: str):
        # Here you would update the value if needed
        if group in self.data:
            self.data[group][var] = value

    def get(self, group: str, value: str, fallback=None) -> any:
        return self.data.get(group, {}).get(value, fallback)

    def getint(self, group: str, value: str, fallback=None) -> int:
        return int(self.data.get(group, {}).get(value, fallback))

    def getbool(self, group: str, value: str, fallback=None) -> bool:
        return bool(self.data.get(group, {}).get(value, fallback))

    def list_all(self):
        options = []
        for section, values in self.data.items():
            options.append(f"|\n|[{section}]\n|")
            for key, value in values.items():
                options.append(f"|   {key} = {value}")
        return options

class log:
    def __init__(self, id: str):
        self.log = []
        self.name = id

    def adlog(self, data: str, np: int = 0):
        self.log.append(data)
        if np != 0:
            self.print_log()

    def clear(self, data: str = ''):
        self.log = [data]
        self.print_log()

    def print_log(self):
        print("\n".join(self.log))
        
    def print_with_border(self, text: str):
        border_char = '#'
        lines = text.splitlines()
        if not lines:
            print(text)
            return
        max_width = max((len(line) for line in lines), default=0)
        border_line = border_char * (max_width + 4)
        print(border_line)
        for line in lines:
            print(f"{border_char} {line.ljust(max_width)} {border_char}")
        print(border_line)

    def logpointer(self,instance, id: str = "cmd"):
        if id in instance.logs:
            return instance.logs[id]
        instance.activelog.adlog("Invalid logpointer")
        return None
