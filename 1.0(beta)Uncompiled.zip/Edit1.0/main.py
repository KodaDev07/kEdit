from kcmd import *; run=False

if __name__ == "__main__":
    cmd_console = EditorCmd()
    cmd_console.activate()