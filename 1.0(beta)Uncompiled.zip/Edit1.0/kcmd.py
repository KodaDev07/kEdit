from editor import Editor; from kcmds import *
import os
global_cmd, cmds, ccmds = {}, {}, {}
def update_command_dicts(instance):
    global global_cmd, cmds, ccmds
    global_cmd = {
        "help": instance.show_help,
        "clear": instance.activelog.clear,
    }
    cmds = {
        "open": instance.open_sprite,
        "new": instance.create_new_canvas,
        "t": lambda: instance.create_new_canvas(['test','5x5']),
    }
    ccmds = {
        "w": lambda: instance.move_cursor(0, -1),
        "s": lambda: instance.move_cursor(0, 1),
        "a": lambda: instance.move_cursor(-1, 0),
        "d": lambda: instance.move_cursor(1, 0),
        "exit": instance.exit_editor,
        "edit": instance.enter_edit_mode,
        "save": instance.save_sprite,
        "undo": instance.undo,
        "redo": instance.redo,
        "insert": instance.add_row_column,
    }
class EditorCmd:
    def add_row(self, position="top", sh=False):
        if position == "top":
            self.editor.data.insert(0, [" "] * len(self.editor.data[0]))
        elif position == "bottom":
            self.editor.data.append([" "] * len(self.editor.data[0]))
        else:
            self.activelog.adlog(f"Invalid position: {position}")
            return
        if not sh:
            self.activelog.adlog(f"Added row at the {position}")
        self.editor.display()
    def add_column(self, position="left", sh=False):
        if position == "left":
            for row in self.editor.data:
                row.insert(0, " ")
            self.move_cursor(1, 0)
        elif position == "right":
            for row in self.editor.data:
                row.append(" ")
        else:
            self.activelog.adlog(f"Invalid position: {position}")
            return
        if not sh:
            self.activelog.adlog(f"Added column at the {position}")
        self.editor.display()
    def add_row_column(self, args):
        if len(args) == 1 and args[0] == "all":
            self.add_row("top", True)
            self.add_row("bottom", True)
            self.add_column("left", True)
            self.add_column("right", True)
            self.activelog.adlog("Inserted all rows and columns")
            self.move_cursor(0, 1)
            return
        if len(args) < 1:
            self.activelog.adlog("Usage: insert <row|col|all> <top/bottom|left/right>")
            return
        try:
            type_, position = args
        except:
            type_ = args[0]
            if type_ == "row":
                position = "top"
            elif type_ == "col":
                position = "left"
            else:
                self.activelog.adlog("Usage: insert <row|col|all> <top/bottom|left/right>")
                return
        if type_ == "row":
            if position not in ["top", "bottom"]:
                self.activelog.adlog("Usage: insert row <top/bottom>")
                return
            self.add_row(position, True)
            if position == "top":
                self.move_cursor(0, -1)
            elif position == "bottom":
                self.move_cursor(0, 1)
        elif type_ == "col":
            if position not in ["left", "right"]:
                self.activelog.adlog("Usage: insert col <left/right>")
                return
            self.add_column(position, True)
            if position == "left":
                self.move_cursor(-1, 0)
            elif position == "right":
                self.move_cursor(1, 0)
        else:
            self.activelog.adlog("Usage: insert <row|col|all> <top/bottom|left/right>")
            return
    def save_sprite(self, args):
        if len(args) != 1:
            self.activelog.adlog('args error')
            return
        sd = input("Enter full download path to save file (or leave blank to use default): ").strip()
        if sd:
            if os.path.isdir(sd):
                directory = sd
            else:
                self.activelog.adlog("Invalid path, using default.")
                directory = self.cwd
        else:
            directory = self.cwd
        filename = args[0]
        try:
            file_path = os.path.join(directory, filename)
            with open(file_path, 'w') as f:
                for row in self.editor.data:
                    f.write(''.join(row) + '\n')
            self.activelog.adlog(f"File saved successfully: {filename}")
            return
        except Exception as e:
            self.activelog.adlog(f"Error saving file {filename}: {e}")
            return
    def editmode_cmd(self, cmd_in):
        e_cmds = {
            "w": lambda: self.move_cursor(0, -1),
            "s": lambda: self.move_cursor(0, 1),
            "a": lambda: self.move_cursor(-1, 0),
            "d": lambda: self.move_cursor(1, 0),
            "p": self.alt_mode,
            "q": self.exit_edit_mode,
            "u": self.undo,
            "r": self.redo
        }
        if cmd_in in e_cmds:
            e_cmds[cmd_in]()
    def create_new_canvas(self, args):
        if len(args) != 2:
            self.activelog.adlog("Usage: new <name> <size>")
            return
        name, size = args
        try:
            width, height = map(int, size.split('x'))
            self.editor = Editor(name, [width, height])
            self.editors.append(self.editor)
            self.activelog = self.logs["edit"]
            self.refresh_cmd()
            self.activelog.adlog(f"Created new canvas: {name} with size {width}x{height}")
            self.draw_mode = True
        except ValueError:
            self.activelog.adlog("Invalid size format\nUse width x height")
    def open_sprite(self, args):
        if len(args) == 0:
            try:
                files = os.listdir(self.cwd)
                if files:
                    os.system("cls||clear")
                    numbered_files = []
                    file_list_str = "Files in save folder:\n"
                    for i, file in enumerate(files, start=1):
                        numbered_files.append(file)
                        file_list_str += f"  {i}. {file}\n"
                    self.activelog.print_with_border(file_list_str)
                    selection = input("Enter file number to open: ").strip()
                    try:
                        sel = int(selection)
                        if 1 <= sel <= len(numbered_files):
                            filename = numbered_files[sel - 1]
                            self.activelog.adlog(f"Selected file: {filename}")
                        else:
                            self.activelog.adlog("Invalid selection.")
                            return
                    except Exception:
                        self.activelog.adlog("Invalid input.")
                        return
                else:
                    self.activelog.adlog("No files found in save folder.")
                    input("Press Enter to continue...")
                    return
            except Exception as e:
                self.activelog.adlog(f"Error listing folder: {e}")
                input("Press Enter to continue...")
                return
        else:
            filename = args[0]
        file_path = os.path.join(self.cwd, filename)
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                self.last_log = self.activelog
                self.activelog.adlog(f"Opened sprite file: {filename}")
                lines = f.readlines()
                data = [list(line.rstrip('\n')) for line in lines]
                self.editor = Editor(filename, [len(data[0]), len(data)])
                self.editor.data = data
                self.editors.append(self.editor)
                self.activelog = self.logs["edit"]
                self.refresh_cmd()
                self.draw_mode = True
        else:
            self.activelog.adlog(f"File not found: {filename}")
    def enter_edit_mode(self):
        self.edit_mode = True
        self.activelog.clear()
        self.activelog.adlog("Edit Mode Active — WASD to move, P to place characters, Q to exit.")
        while self.edit_mode:
            self.editor.display()
            key = input(':>')
            if key == "w":
                self.move_cursor(0, -1)
            elif key == "s":
                self.move_cursor(0, 1)
            elif key == "a":
                self.move_cursor(-1, 0)
            elif key == "d":
                self.move_cursor(1, 0)
            elif key == "u":
                self.undo()
            elif key == "r":
                self.redo()
            elif key == "p":
                self.alt_mode()
            elif key == "q":
                self.exit_edit_mode()
    def exit_edit_mode(self):
        self.activelog.adlog("Exiting Edit Mode")
        self.edit_mode = False
    def exit_editor(self):
        self.last_log = self.activelog
        self.activelog.adlog("Quit editor")
        self.activelog = self.last_log
        self.refresh_cmd()
        self.editor = None
        self.draw_mode = False
    def undo(self):
        self.editor.undo()
        self.editor.display()
    def redo(self):
        self.editor.redo()
        self.editor.display()
    def move_cursor(self, dx, dy):
        self.editor.save_state()
        self.editor.cursor_x = max(0, min(len(self.editor.data[0]) - 1, self.editor.cursor_x + dx))
        self.editor.cursor_y = max(0, min(len(self.editor.data) - 1, self.editor.cursor_y + dy))
    def alt_mode(self):
        def key_to_char(name):
            if len(name) == 1:
                return name
            self.activelog.adlog(f'{name}: Invalid char!')
            return " "
        while True:
            key = input('place:')
            if key == "exit":
                self.activelog.adlog("Exiting ALT mode", 1)
                break
            ch = key_to_char(key)
            if ch:
                if len(ch) == 1:
                    y, x = self.editor.cursor_y, self.editor.cursor_x
                    self.editor.data[y][x] = ch
                    self.activelog.adlog(f"Placed '{ch}' at ({x},{y})", 1)
                    break
    def show_help(self):
        help_text = """
|--- Help ---|
|# X on terminal to close program #
|
|~ global
|-   help: Display this help message
|-   clear: Clear the log
|
|~ cmd
|-   new <name> <size {wxh}>: Create new canvas
|-   open <file>/None: opens the specified sprite file
|-   launch <id>: launch an active editor
|-   dismiss <id>: dismiss an active editor
|
|~ canvas                *row*       *col*
|-   insert: <row|col> <top/bottom|left/right>
|-   undo: Undo the canvas state
|-   redo: Redo the canvas state
|-   edit: Enter edit mode (WASD to move, P to place char(shift to place special/uppercase), Q to exit)
|-   save <name>: Save sprite to save path
|-   exit: Quit to cmd
"""
        self.activelog.adlog(help_text)
    def __init__(self):
        self.editors = []
        self.active = True
        sd = input("Enter full download path: ")
        while not os.path.isdir(sd):
            sd = input("Invalid path! Enter full download path: ")
        self.cwd = sd
        self.draw_mode = False
        self.cursor = ":>"
    def refresh_cmd(self):
        update_command_dicts(self)
    def activate(self):
        self.logs = {
        "cmd": log('cmd'),
        "edit": log('edit'),
        "config": log('config')
        }
        self.activelog = self.logs["cmd"]
        self.refresh_cmd()
        self.draw_mode = False
        self.edit_mode = False
        while self.active:
            os.system('cls||clear')
            if self.draw_mode:
                self.editor.display()
                if self.activelog.log:
                    self.activelog.print_log()
            else:
                combined = "\n".join(self.activelog.log) + "\nDir: " + self.cwd
                self.activelog.print_with_border(combined)
                if len(self.editors) != 0:
                    open_editors = '|'
                    for i, editor in enumerate(self.editors):
                        open_editors = f"{open_editors}{i}({editor.id})|"
                    print(open_editors)
            c = input(f"{self.cursor} ").strip().split(' ')
            cmd = c[0]
            if not self.draw_mode and cmd == 'launch' and len(c) == 2:
                try:
                    editor_index = int(c[1])
                    if 0 <= editor_index < len(self.editors):
                        self.last_log = self.activelog
                        self.editor = self.editors[editor_index]
                        self.activelog.adlog(f"Launched [{editor_index}]{self.editor.id}")
                        self.activelog = self.activelog.logpointer(self,"edit")
                        self.draw_mode = True
                        self.editor.display() 
                    else:
                        self.activelog.adlog("Invalid editor number.")
                except ValueError:
                    self.activelog.adlog("Please provide a number.")
            elif not self.draw_mode and cmd == 'dismiss' and len(c) == 2:
                try:
                    editor_index = int(c[1])
                    if 0 <= editor_index < len(self.editors):
                        del self.editors[editor_index]
                        self.activelog.adlog(f"Dismissed editor [{editor_index}]")
                    else:
                        self.activelog.adlog("Invalid editor number.")
                except ValueError:
                    self.activelog.adlog("Please provide a number.")
            elif cmd not in global_cmd:
                if cmd in cmds and not self.draw_mode:
                    try:
                        cmds[cmd](c[1:])
                    except Exception:
                        cmds[cmd]()
                elif cmd in ccmds and self.draw_mode:
                    try:
                        ccmds[cmd](c[1:])
                    except Exception:
                        ccmds[cmd]()
            elif cmd in global_cmd:
                try:
                    global_cmd[cmd](c[1:])
                except Exception:
                    global_cmd[cmd]()