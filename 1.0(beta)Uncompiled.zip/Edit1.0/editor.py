import os
class Editor:
    def __init__(self, id: str, size: list = [40, 20], data=None):
        if data is None:
            data = [[" "] * size[0] for _ in range(size[1])]
        self.id = id
        self.data = data
        self.cursor_x = 0
        self.cursor_y = 0
        self.undo_stack = []
        self.redo_stack = []
        self.header = "Editor"
        self.border_char = "#"
        self.cursor_symbol = "@"
        self.bg_style = ""
    def save_state(self):
        self.undo_stack.append([row[:] for row in self.data])
        if len(self.undo_stack) > 10:
            self.undo_stack.pop(0)
    def undo(self):
        self.redo_stack.append([row[:] for row in self.data])
        self.data = self.undo_stack.pop()
    def redo(self):
        if self.redo_stack:
            self.undo_stack.append([row[:] for row in self.data])
            self.data = self.redo_stack.pop()
    def display(self, cursor_x=None, cursor_y=None, logs=None):
        os.system('cls||clear')
        cursor_x = self.cursor_x if cursor_x is None else cursor_x
        cursor_y = self.cursor_y if cursor_y is None else cursor_y
        print(f"\n{self.header}")
        numx = " " + "".join(str(x % 10) for x in range(len(self.data[0])))
        print(numx)
        border_line = self.border_char * (len(self.data[0]) + 2)
        print(border_line)
        for y, row in enumerate(self.data):
            line = ""
            for x, ch in enumerate(row):
                line += self.cursor_symbol if (x == cursor_x and y == cursor_y) else ch
            print(f"{border_line[0]}{line}{border_line[0]}{y}")
        print(border_line)
        print(f"(x, y):({cursor_x}, {cursor_y})")
        if self.bg_style:
            print(f"Background style: {self.bg_style}")